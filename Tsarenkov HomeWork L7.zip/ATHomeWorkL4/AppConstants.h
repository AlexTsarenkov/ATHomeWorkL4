//
//  AppConstants.h
//  ATHomeWorkL4
//
//  Created by Alexey Tsarenkov on 21.04.15.
//  Copyright (c) 2015 alextsarenkov. All rights reserved.
//

#ifndef ATHomeWorkL4_AppConstants_h
#define ATHomeWorkL4_AppConstants_h

// константы для dictionary
#define KEY_FOR_ARRAY@"keyArray"

// имена нотификаций
#define NOTIF_ARRAY @"arrayNotif"


#endif
