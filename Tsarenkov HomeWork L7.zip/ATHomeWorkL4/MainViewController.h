//
//  MainViewController.h
//  ATHomeWorkL4
//
//  Created by Alexey Tsarenkov on 13.04.15.
//  Copyright (c) 2015 alextsarenkov. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "ViewController.h"
@interface MainViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *techButton;
@property (strong, nonatomic) IBOutlet UIButton *musicButton;

@end
